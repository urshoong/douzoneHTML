function Header() {
    
    return (
        <h1>Redux 연습</h1>
    );
}

export default Header;